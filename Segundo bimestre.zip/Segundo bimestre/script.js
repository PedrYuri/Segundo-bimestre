// 1
function verificarTriangulo() {
    const x = Number(document.getElementById("triX").value);
    const y = Number(document.getElementById("triY").value);
    const z = Number(document.getElementById("triZ").value);
    let res = "";

    if (x < y + z && y < x + z && z < x + y) {
        if (x === y && y === z) {
            res = "Triângulo Equilátero";
        } else if (x === y || y === z || x === z) {
            res = "Triângulo Isósceles";
        } else {
            res = "Triângulo Escaleno";
        }
    } else {
        res = "Não forma um triângulo";
    }
    document.getElementById("resTriangulo").innerText = res;
}

// 2
function calcularIMC() {
    const peso = Number(document.getElementById("peso").value);
    const altura = Number(document.getElementById("altura").value);
    const imc = peso / (altura * altura);
    let classificacao = "";

    if (imc < 18.5) classificacao = "Abaixo do peso";
    else if (imc < 25) classificacao = "Peso normal";
    else if (imc < 30) classificacao = "Sobrepeso";
    else if (imc < 35) classificacao = "Obesidade grau 1";
    else if (imc < 40) classificacao = "Obesidade grau 2";
    else classificacao = "Obesidade grau 3";

    document.getElementById("resIMC").innerText = `IMC: ${imc.toFixed(2)} - ${classificacao}`;
}

// 3
function calcularImposto() {
    const ano = Number(document.getElementById("anoCarro").value);
    const valor = Number(document.getElementById("valorCarro").value);
    let taxa = (ano < 1990) ? 0.01 : 0.015;
    const imposto = valor * taxa;

    document.getElementById("resImposto").innerText = `Imposto a pagar: R$ ${imposto.toFixed(2)}`;
}

// 4
function calcularSalario() {
    const salario = Number(document.getElementById("salarioAtual").value);
    const cargo = document.getElementById("cargo").value.trim().toLowerCase();
    let aumento = 0;

    if (cargo === "gerente") aumento = 0.10;
    else if (cargo === "engenheiro") aumento = 0.20;
    else if (cargo === "tecnico") aumento = 0.30;
    else aumento = 0.40;

    const novoSalario = salario * (1 + aumento);
    const diferenca = novoSalario - salario;

    document.getElementById("resSalario").innerText = 
    `Salário antigo: R$${salario.toFixed(2)}, Novo salário: R$${novoSalario.toFixed(2)}, Diferença: R$${diferenca.toFixed(2)}`;
}

// 5
function calcularCredito() {
    const saldo = Number(document.getElementById("saldoMedio").value);
    let credito = 0;

    if (saldo <= 500) credito = 0;
    else if (saldo <= 1000) credito = saldo * 0.3;
    else if (saldo <= 3000) credito = saldo * 0.4;
    else credito = saldo * 0.5;

    document.getElementById("resCredito").innerText = 
    `Saldo médio: R$${saldo.toFixed(2)}, Crédito: R$${credito.toFixed(2)}`;
}

// 6
function calcularLanche() {
    const codigo = Number(document.getElementById("codItem").value);
    const qtd = Number(document.getElementById("qtdItem").value);
    let preco = 0;

    if (codigo === 100) preco = 1.70;
    else if (codigo === 101) preco = 2.30;
    else if (codigo === 102) preco = 2.60;
    else if (codigo === 103) preco = 2.40;
    else if (codigo === 104) preco = 2.50;
    else if (codigo === 105) preco = 1.00;
    else {
        document.getElementById("resLanche").innerText = "Código inválido";
        return;
    }

    const total = preco * qtd;
    document.getElementById("resLanche").innerText = `Total a pagar: R$${total.toFixed(2)}`;
}

// 7
function calcularVenda() {
    const preco = Number(document.getElementById("precoProduto").value);
    const condicao = document.getElementById("condicao").value;
    let total = preco;

    if (condicao === "a") total = preco * 0.9;
    else if (condicao === "b") total = preco * 0.85;
    else if (condicao === "c") total = preco;
    else if (condicao === "d") total = preco * 1.10;

    document.getElementById("resVenda").innerText = `Total a pagar: R$${total.toFixed(2)}`;
}

// 8
function calcularSalarioProfessor() {
    const nivel = Number(document.getElementById("nivelProf").value);
    const horas = Number(document.getElementById("horasAula").value);
    let valorHora = 0;

    if (nivel === 1) valorHora = 12;
    else if (nivel === 2) valorHora = 17;
    else if (nivel === 3) valorHora = 25;
    else {
        document.getElementById("resSalProf").innerText = "Nível inválido";
        return;
    }

    const salario = valorHora * horas * 4.5;
    document.getElementById("resSalProf").innerText = `Salário: R$${salario.toFixed(2)}`;
}